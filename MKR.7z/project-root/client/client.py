#!/usr/bin/env python3
# client.py
"""
Клієнт бере COLLATZ_COUNT, SERVER_HOST, SERVER_PORT із змінних оточення,
відкриває TCP-з'єднання, надсилає N як рядок з '\n', чекає відповіді і виводить її.
"""
import os
import socket
import sys

BUFFER_SIZE = 4096

def main():
    N_str = os.environ.get("COLLATZ_COUNT")
    if not N_str:
        print("ERROR: COLLATZ_COUNT env var is not set", file=sys.stderr)
        sys.exit(2)

    try:
        N = int(N_str)
        if N <= 0:
            raise ValueError()
    except Exception:
        print("ERROR: COLLATZ_COUNT must be a positive integer", file=sys.stderr)
        sys.exit(3)

    HOST = os.environ.get("SERVER_HOST", "server")
    PORT = int(os.environ.get("SERVER_PORT", "9000"))

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.connect((HOST, PORT))
        except Exception as e:
            print(f"ERROR: cannot connect to {HOST}:{PORT} -> {e}", file=sys.stderr)
            sys.exit(4)

        # надсилаємо N в текстовому форматі з новим рядком
        s.sendall(f"{N}\n".encode("utf-8"))

        # отримуємо відповідь до EOF або до завершення
        data = b""
        while True:
            chunk = s.recv(BUFFER_SIZE)
            if not chunk:
                break
            data += chunk

        if not data:
            print("No response from server", file=sys.stderr)
            sys.exit(5)

        resp = data.decode("utf-8").strip()
        # виводимо у stdout (щоб docker logs показував)
        print(resp)

if __name__ == "__main__":
    main()
