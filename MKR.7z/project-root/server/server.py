#!/usr/bin/env python3
# server.py
"""
Сервер приймає текстовий рядок з числом N (наприклад "100\n"),
для кожного i від 1 до N обчислює кількість кроків послідовності Колатца до 1,
після чого відправляє клієнту середнє значення (float) у вигляді рядка з '\n'
і закриває з'єднання.
Підтримується налаштування порту через змінну середовища SERVER_PORT (за замовчуванням 9000).
"""
import os
import socket
import sys

HOST = "0.0.0.0"
PORT = int(os.environ.get("SERVER_PORT", "9000"))
BUFFER_SIZE = 4096

# кеш для пришвидшення (memoization)
_collatz_cache = {1: 0}

def collatz_steps(n: int) -> int:
    """
    Повертає кількість кроків, щоб дійти до 1 для числа n.
    Використовує кеш для оптимізації.
    """
    if n in _collatz_cache:
        return _collatz_cache[n]

    path = []
    x = n
    while x not in _collatz_cache:
        path.append(x)
        if x % 2 == 0:
            x = x // 2
        else:
            x = 3 * x + 1

    # тепер у _collatz_cache є значення для x
    steps = _collatz_cache[x]
    # зворотне заповнення кешу
    for v in reversed(path):
        steps += 1
        _collatz_cache[v] = steps
    return _collatz_cache[n]

def handle_client(conn: socket.socket, addr):
    try:
        data = b""
        # читаємо до \n або поки клієнт не закриє з'єднання
        while True:
            chunk = conn.recv(BUFFER_SIZE)
            if not chunk:
                break
            data += chunk
            if b"\n" in chunk:
                break

        if not data:
            return

        text = data.decode("utf-8").strip()
        try:
            N = int(text)
            if N <= 0:
                raise ValueError("N must be positive")
        except Exception as e:
            resp = f"ERROR: invalid N: {e}\n"
            conn.sendall(resp.encode("utf-8"))
            return

        # обчислення кроків для 1..N
        total_steps = 0
        for i in range(1, N + 1):
            total_steps += collatz_steps(i)

        average = total_steps / N
        resp = f"{average}\n"
        conn.sendall(resp.encode("utf-8"))
    finally:
        try:
            conn.shutdown(socket.SHUT_RDWR)
        except Exception:
            pass
        conn.close()

def run():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((HOST, PORT))
        s.listen(1)  # достатньо обробити одного клієнта за умовою завдання
        print(f"Server listening on {HOST}:{PORT}", flush=True)
        conn, addr = s.accept()
        print(f"Accepted connection from {addr}", flush=True)
        handle_client(conn, addr)
        print("Finished handling one client; server exiting.", flush=True)

if __name__ == "__main__":
    try:
        run()
    except KeyboardInterrupt:
        print("Interrupted, exiting.", file=sys.stderr)
        sys.exit(0)
